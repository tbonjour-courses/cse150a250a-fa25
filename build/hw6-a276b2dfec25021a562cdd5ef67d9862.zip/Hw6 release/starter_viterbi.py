from numpy.typing import NDArray
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm


def load_data_viterbi(
    emission_file: str = "emissionMatrix.txt",
    initial_file: str = "initialStateDistribution.txt",
    obs_file: str = "observations.txt",
    transition_file: str = "transitionMatrix.txt",
) -> tuple[NDArray]:
    """
    Loads the necessary data for the Hidden Markov Model (HMM) Viterbi algorithm
    from specified text files.

    Args:
        emission_file (str, optional): Filepath for the Emission Matrix (B).
            Defaults to "emissionMatrix.txt".
        initial_file (str, optional): Filepath for the Initial State Distribution (Pi).
            Defaults to "initialStateDistribution.txt".
        obs_file (str, optional): Filepath for the Observation Sequence.
            Defaults to "observations.txt".
        transition_file (str, optional): Filepath for the Transition Matrix (A).
            Defaults to "transitionMatrix.txt".

    Returns:
        tuple[NDArray]: A tuple containing four NumPy arrays:
            (emissions, initials, observations, transitions)
            - emissions - shape (S , M): Emission matrix (S states, M possible observations).
            - initials - shape (S,): Initial state distribution vector.
            - observations - shape (T,): Sequence of observations (T time steps).
            - transitions - shape (S , S): Transition matrix.
    """
    raise NotImplementedError


def viterbi(
    emissions: NDArray, initials: NDArray, observations: NDArray, transitions: NDArray
) -> NDArray:
    """
    Implements the Viterbi algorithm to find the most likely sequence of hidden
    states given a sequence of observations and the HMM parameters.

    Use log-probabilities to avoid underflow issues with small probability values.

    Args:
        emissions (NDArray): The Emission Matrix (B) of shape (S, M).
        initials (NDArray): The Initial State Distribution (Pi) of shape (S,).
        observations (NDArray): The sequence of observations of shape (T,).
        transitions (NDArray): The Transition Matrix (A) of shape (S, S).

    Returns:
        NDArray: The optimal path (most likely sequence of hidden states)
            of shape (T,) as an array of integer indices.
    """
    raise NotImplementedError


def decoded_answer() -> str:
    """
    Returns a specific hardcoded string - which is the decoded answer you found.

    Returns:
        str: The hardcoded decoded message.
    """
    raise NotImplementedError
